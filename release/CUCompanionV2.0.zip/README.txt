﻿Casualties: Unknown · Companion Mod v2.0
========================================

[About & Credits]
Creator 1: Hchime-ai
Creator 2: meowgreen
Creator 3: 小褐XHchime-ai
Development Tooling: Codex-type tools

[Official Links]
Creator Support (Patreon): https://www.patreon.com/cw/MeowgreenXiaoLu67
Developer GitHub: https://github.com/Hchime-AI
Developer X (Twitter): https://x.com/Lgreen_mie67
Developer YouTube: https://www.youtube.com/@Hchime-ai
Developer Discord: https://discord.gg/4F7cYhKpex

[Installation]
Copy CUCompanion.dll (or CUCompanion2.0.dll) into your BepInEx/plugins/ directory.
Run the game. No external config files required to start.